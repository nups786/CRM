<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-01 05:42:07 --> 404 Page Not Found: admin/Adminlte/inlinegeneral
ERROR - 2017-10-01 05:42:53 --> 404 Page Not Found: admin/Adminlte/inlinegeneral
ERROR - 2017-10-01 05:54:11 --> 404 Page Not Found: Layout/top-nav.html
ERROR - 2017-10-01 06:27:04 --> 404 Page Not Found: Public/dist
ERROR - 2017-10-01 06:27:04 --> 404 Page Not Found: Public/dist
